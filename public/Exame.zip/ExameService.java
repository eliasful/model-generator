package br.com.rhppp.service;
import br.com.fiscobase.repository.GenericVsRepository;
import br.com.rhppp.model.Exame;
public interface ExameService extends GenericVsRepository<Exame> {
}