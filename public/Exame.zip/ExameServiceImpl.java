package br.com.rhppp.service.impl;
import br.com.fiscobase.repository.impl.GenericVsRepositoryImpl;
import br.com.rhppp.model.Exame;
import br.com.rhppp.service.ExameService;
import org.springframework.stereotype.Service;
@Service
public class ExameServiceImpl extends GenericVsRepositoryImpl<Exame> implements ExameService {
}