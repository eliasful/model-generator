package br.com.rhppp.controller;
import br.com.rhppp.model.Exame;
import br.com.rhppp.service.ExameService;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpServletRequest;
@Controller
@RequestMapping(value = "/secured/cadastros/exame")
public class ExameController {    @Autowired
    private ExameService exameService;
    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String app() {
        return "/secured/cadastros/exame";
    }
    @ResponseBody
    @RequestMapping(value = "/listar", method = RequestMethod.GET)
    public String listar() {
        try {
            return new Gson().toJson(exameService.list(Exame.class));
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    @ResponseBody
    @RequestMapping(value = "/carregar/{id}", method = RequestMethod.GET)
    public String carregar(@PathVariable("id") Integer id) {
        try{
           return new Gson().toJson(exameService.findBy(Exame.class, "idexame", id));
        }catch(Exception e){
           e.printStackTrace();
           return null
        }
    }
    @ResponseBody
    @RequestMapping(value = "/", method = RequestMethod.POST)
    public String salvar(Exame exame){
        try {
            if (exame == null) return null;
            Integer id = exameService.save(exame);
            exame.setIdexame(id);
            return new Gson().toJson(exame);
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
    @ResponseBody
    @RequestMapping(value = "/excluir/{id}", method = RequestMethod.DELETE)
    public Integer excluir(@PathVariable("id") Integer id){
        try {
            Exame exame = new Exame();
            exame.setIdexame(id);
            return exameService.delete(exame);
        }catch (Exception e){
            e.printStackTrace();
            return -1;
        }
    }
}