package br.com.rhapp.controller;
import br.com.rhapp.model.Pessoa;
import br.com.rhapp.service.PessoaService;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpServletRequest;
@Controller
@RequestMapping(value = "/secured/cadastros/pessoa")
public class PessoaController {    @Autowired
    private PessoaService pessoaService;
    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String app() {
        return "/secured/cadastros/pessoa";
    }
    @ResponseBody
    @RequestMapping(value = "/listar", method = RequestMethod.GET)
    public String listar() {
        try {
            return new Gson().toJson(pessoaService.list(Pessoa.class));
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    @ResponseBody
    @RequestMapping(value = "/carregar/{id}", method = RequestMethod.GET)
    public String carregar(@PathVariable("id") Integer id) {
        return new Gson().toJson(pessoaService.findBy(Pessoa.class, "idpessoa", id));
    }
    @ResponseBody
    @RequestMapping(value = "/", method = RequestMethod.POST)
    public String salvar(Pessoa pessoa){
        try {
            if (pessoa == null) return null;
            Integer id = pessoaService.save(pessoa);
            pessoa.setIdpessoa(id)
            return new Gson().toJson(pessoa);
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
    @ResponseBody
    @RequestMapping(value = "/excluir/{id}", method = RequestMethod.DELETE)
    public Integer excluir(@PathVariable("id") Integer id){
        try {
            Pessoa pessoa = new Pessoa();
            pessoa.setIdpessoa(id);
            return pessoaService.delete(pessoa);
        }catch (Exception e){
            e.printStackTrace();
            return -1;
        }
    }
}