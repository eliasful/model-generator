package br.com.rhapp.service;
import br.com.fiscobase.repository.GenericVsRepository;
import br.com.rhapp.model.pessoa;
public interface PessoaService extends GenericVsRepository<Pessoa> {
}