package br.com.rhapp.service.impl;
import br.com.fiscobase.repository.impl.GenericVsRepositoryImpl;
import br.com.rhapp.model.pessoa;
import br.com.rhapp.service.pessoaService;
import org.springframework.stereotype.Service;
@Service
public class PessoaServiceImpl extends GenericVsRepositoryImpl<Pessoa> implements PessoaService {
}