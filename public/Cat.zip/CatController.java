package br.com.rhppp.controller;
import br.com.rhppp.model.Cat;
import br.com.rhppp.service.CatService;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpServletRequest;
@Controller
@RequestMapping(value = "/secured/cadastros/cat")
public class CatController {    @Autowired
    private CatService catService;
    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String app() {
        return "/secured/cadastros/cat";
    }
    @ResponseBody
    @RequestMapping(value = "/listar", method = RequestMethod.GET)
    public String listar() {
        try {
            return new Gson().toJson(catService.list(Cat.class));
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    @ResponseBody
    @RequestMapping(value = "/carregar/{id}", method = RequestMethod.GET)
    public String carregar(@PathVariable("id") Integer id) {
        return new Gson().toJson(catService.findBy(Cat.class, "idcat", id));
    }
    @ResponseBody
    @RequestMapping(value = "/", method = RequestMethod.POST)
    public String salvar(Cat cat){
        try {
            if (cat == null) return null;
            Integer id = catService.save(cat);
            cat.setIdcat(id)
            return new Gson().toJson(cat);
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
    @ResponseBody
    @RequestMapping(value = "/excluir/{id}", method = RequestMethod.DELETE)
    public Integer excluir(@PathVariable("id") Integer id){
        try {
            Cat cat = new Cat();
            cat.setIdcat(id);
            return catService.delete(cat);
        }catch (Exception e){
            e.printStackTrace();
            return -1;
        }
    }
}