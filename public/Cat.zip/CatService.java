package br.com.rhppp.service;
import br.com.fiscobase.repository.GenericVsRepository;
import br.com.rhppp.model.cat;
public interface CatService extends GenericVsRepository<Cat> {
}