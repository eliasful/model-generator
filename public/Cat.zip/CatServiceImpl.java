package br.com.rhppp.service.impl;
import br.com.fiscobase.repository.impl.GenericVsRepositoryImpl;
import br.com.rhppp.model.cat;
import br.com.rhppp.service.catService;
import org.springframework.stereotype.Service;
@Service
public class CatServiceImpl extends GenericVsRepositoryImpl<Cat> implements CatService {
}