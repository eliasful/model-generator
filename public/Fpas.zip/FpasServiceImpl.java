package br.com.rhppp.service.impl;
import br.com.fiscobase.repository.impl.GenericVsRepositoryImpl;
import br.com.rhppp.model.Fpas;
import br.com.rhppp.service.FpasService;
import org.springframework.stereotype.Service;
@Service
public class FpasServiceImpl extends GenericVsRepositoryImpl<Fpas> implements FpasService {
}