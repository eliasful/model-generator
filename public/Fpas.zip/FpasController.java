package br.com.rhppp.controller;
import br.com.rhppp.model.Fpas;
import br.com.rhppp.service.FpasService;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpServletRequest;
@Controller
@RequestMapping(value = "/secured/cadastros/fpas")
public class FpasController {    @Autowired
    private FpasService fpasService;
    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String app() {
        return "/secured/cadastros/fpas";
    }
    @ResponseBody
    @RequestMapping(value = "/listar", method = RequestMethod.GET)
    public String listar() {
        try {
            return new Gson().toJson(fpasService.list(Fpas.class));
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    @ResponseBody
    @RequestMapping(value = "/carregar/{id}", method = RequestMethod.GET)
    public String carregar(@PathVariable("id") Integer id) {
        try{
           return new Gson().toJson(fpasService.findBy(Fpas.class, "idfpas", id));
        }catch(Exception e){
           e.printStackTrace();
           return null;
        }
    }
    @ResponseBody
    @RequestMapping(value = "/", method = RequestMethod.POST)
    public String salvar(Fpas fpas){
        try {
            if (fpas == null) return null;
            Integer id = fpasService.save(fpas);
            fpas.setIdfpas(id);
            return new Gson().toJson(fpas);
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
    @ResponseBody
    @RequestMapping(value = "/excluir/{id}", method = RequestMethod.DELETE)
    public Integer excluir(@PathVariable("id") Integer id){
        try {
            Fpas fpas = new Fpas();
            fpas.setIdfpas(id);
            return fpasService.delete(fpas);
        }catch (Exception e){
            e.printStackTrace();
            return -1;
        }
    }
}