package br.com.rhppp.service;
import br.com.fiscobase.repository.GenericVsRepository;
import br.com.rhppp.model.Fpas;
public interface FpasService extends GenericVsRepository<Fpas> {
}