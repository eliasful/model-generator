package br.com.rhapp.service.impl;
import br.com.fiscobase.repository.impl.GenericVsRepositoryImpl;
import br.com.rhapp.model.estado;
import br.com.rhapp.service.estadoService;
import org.springframework.stereotype.Service;
@Service
public class EstadoServiceImpl extends GenericVsRepositoryImpl<Estado> implements EstadoService {
}