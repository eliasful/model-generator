package br.com.rhapp.controller;
import br.com.rhapp.model.Estado;
import br.com.rhapp.service.EstadoService;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpServletRequest;
@Controller
@RequestMapping(value = "/secured/cadastros/estado")
public class EstadoController {    @Autowired
    private EstadoService estadoService;
    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String app() {
        return "/secured/cadastros/estado";
    }
    @ResponseBody
    @RequestMapping(value = "/listar", method = RequestMethod.GET)
    public String listar() {
        try {
            return new Gson().toJson(estadoService.list(Estado.class));
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    @ResponseBody
    @RequestMapping(value = "/carregar/{id}", method = RequestMethod.GET)
    public String carregar(@PathVariable("id") Integer id) {
        return new Gson().toJson(estadoService.findBy(Estado.class, "idestado", id));
    }
    @ResponseBody
    @RequestMapping(value = "/", method = RequestMethod.POST)
    public String salvar(Estado estado){
        try {
            if (estado == null) return null;
            Integer id = estadoService.save(estado);
            estado.setIdestado(id)
            return new Gson().toJson(estado);
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
    @ResponseBody
    @RequestMapping(value = "/excluir/{id}", method = RequestMethod.DELETE)
    public Integer excluir(@PathVariable("id") Integer id){
        try {
            Estado estado = new Estado();
            estado.setIdestado(id);
            return estadoService.delete(estado);
        }catch (Exception e){
            e.printStackTrace();
            return -1;
        }
    }
}