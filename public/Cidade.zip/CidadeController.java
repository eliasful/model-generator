package br.com.rhapp.controller;
import br.com.rhapp.model.Cidade;
import br.com.rhapp.service.CidadeService;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpServletRequest;
@Controller
@RequestMapping(value = "/secured/cadastros/cidade")
public class CidadeController {    @Autowired
    private CidadeService cidadeService;
    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String app() {
        return "/secured/cadastros/cidade";
    }
    @ResponseBody
    @RequestMapping(value = "/listar", method = RequestMethod.GET)
    public String listar() {
        try {
            return new Gson().toJson(cidadeService.list(Cidade.class));
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    @ResponseBody
    @RequestMapping(value = "/carregar/{id}", method = RequestMethod.GET)
    public String carregar(@PathVariable("id") Integer id) {
        return new Gson().toJson(cidadeService.findBy(Cidade.class, "idcidade", id));
    }
    @ResponseBody
    @RequestMapping(value = "/", method = RequestMethod.POST)
    public String salvar(Cidade cidade){
        try {
            if (cidade == null) return null;
            Integer id = cidadeService.save(cidade);
            cidade.setIdcidade(id)
            return new Gson().toJson(cidade);
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
    @ResponseBody
    @RequestMapping(value = "/excluir/{id}", method = RequestMethod.DELETE)
    public Integer excluir(@PathVariable("id") Integer id){
        try {
            Cidade cidade = new Cidade();
            cidade.setIdcidade(id);
            return cidadeService.delete(cidade);
        }catch (Exception e){
            e.printStackTrace();
            return -1;
        }
    }
}