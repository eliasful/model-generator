package br.com.rhapp.service;
import br.com.fiscobase.repository.GenericVsRepository;
import br.com.rhapp.model.cidade;
public interface CidadeService extends GenericVsRepository<Cidade> {
}