package br.com.rhapp.service.impl;
import br.com.fiscobase.repository.impl.GenericVsRepositoryImpl;
import br.com.rhapp.model.cidade;
import br.com.rhapp.service.cidadeService;
import org.springframework.stereotype.Service;
@Service
public class CidadeServiceImpl extends GenericVsRepositoryImpl<Cidade> implements CidadeService {
}