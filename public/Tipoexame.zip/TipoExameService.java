package br.com.rhppp.service;
import br.com.fiscobase.repository.GenericVsRepository;
import br.com.rhppp.model.TipoExame;
public interface TipoExameService extends GenericVsRepository<TipoExame> {
}