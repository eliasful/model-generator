package br.com.rhppp.service.impl;
import br.com.fiscobase.repository.impl.GenericVsRepositoryImpl;
import br.com.rhppp.model.TipoExame;
import br.com.rhppp.service.TipoExameService;
import org.springframework.stereotype.Service;
@Service
public class TipoExameServiceImpl extends GenericVsRepositoryImpl<TipoExame> implements TipoExameService {
}