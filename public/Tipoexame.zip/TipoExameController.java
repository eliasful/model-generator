package br.com.rhppp.controller;
import br.com.rhppp.model.TipoExame;
import br.com.rhppp.service.TipoExameService;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpServletRequest;
@Controller
@RequestMapping(value = "/secured/cadastros/tipoexame")
public class TipoExameController {    @Autowired
    private TipoExameService tipoexameService;
    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String app() {
        return "/secured/cadastros/tipoexame";
    }
    @ResponseBody
    @RequestMapping(value = "/listar", method = RequestMethod.GET)
    public String listar() {
        try {
            return new Gson().toJson(tipoexameService.list(TipoExame.class));
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    @ResponseBody
    @RequestMapping(value = "/carregar/{id}", method = RequestMethod.GET)
    public String carregar(@PathVariable("id") Integer id) {
        return new Gson().toJson(tipoexameService.findBy(TipoExame.class, "idtpexame", id));
    }
    @ResponseBody
    @RequestMapping(value = "/", method = RequestMethod.POST)
    public String salvar(TipoExame tipoexame){
        try {
            if (tipoexame == null) return null;
            Integer id = tipoexameService.save(tipoexame);
            tipoexame.setIdtpexame(id);
            return new Gson().toJson(tipoexame);
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
    @ResponseBody
    @RequestMapping(value = "/excluir/{id}", method = RequestMethod.DELETE)
    public Integer excluir(@PathVariable("id") Integer id){
        try {
            TipoExame tipoexame = new TipoExame();
            tipoexame.setIdtpexame(id);
            return tipoexameService.delete(tipoexame);
        }catch (Exception e){
            e.printStackTrace();
            return -1;
        }
    }
}